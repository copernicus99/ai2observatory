<?php
/**
* Template Name: ReserveThemex
*/


 get_header('reserve');?>
 
              <?php if ( have_posts() ) : while ( have_posts() ) : the_post();
				the_content();
				endwhile; endif; 
				?>
				
</body>
</html>