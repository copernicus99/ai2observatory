<?php
	/*
	   Template Name: ReserveThemex
	*/
	get_header();
?>
<?php get_footer(); ?>

<div class="contact-form">
                    <h3>Leave A Message</h3>
                    <p>Write some words</p>
                    <?php echo do_shortcode('[ninja_form id=1]'); ?>
                </div><!--contact-form-->









